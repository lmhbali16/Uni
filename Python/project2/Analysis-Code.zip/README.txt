These four folders contain the analysis tools used in each of the questions in our report. 
The names of the folder correspond to the question that the folder was used to analyse.